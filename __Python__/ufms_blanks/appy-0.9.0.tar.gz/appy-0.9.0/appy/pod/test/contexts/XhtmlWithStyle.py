# -*- coding: utf-8 -*-
xhtmlInput = '''
<p><meta http-equiv="CONTENT-TYPE" content="text/html; charset=utf-8" /><title></title><meta name="GENERATOR" content="OpenOffice.org 3.0 (Win32)" /><style type="text/css">
    &lt;!--
        @page { margin: 2cm }
        P { margin-bottom: 0.21cm }
    --&gt;
    </style>
<p>concepteurs de normes : membres des
cabinets ministériels et les administrations.</p>
<p><br /><br /></p>
<p>Laurent, membre du cabinet du Ministre
de l'énergie, doit rédiger un arrêté du Gouvernement wallon
relatif à l'octroi d'une prime à l'isolation. Il peut télécharger
le canevas typ</p>
</p>'''
