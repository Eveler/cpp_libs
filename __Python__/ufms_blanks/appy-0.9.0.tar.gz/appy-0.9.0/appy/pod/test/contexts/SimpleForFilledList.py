list1 = ['Hello', 'World', 45, True]
