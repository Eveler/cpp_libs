data = [ \
  ['1', 2, 'three'],
  ['A', 'BB', 'CCC']
]
