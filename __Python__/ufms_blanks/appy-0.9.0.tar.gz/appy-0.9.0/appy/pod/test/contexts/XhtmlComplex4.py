# -*- coding: utf-8 -*-
xhtmlInput = '''
<p>Champ FCK</p>
<ol>
    <li>aaaa
    <ol>
        <li>Azerty</li>
        <li>aaaa</li>
    </ol>
    </li>
    <li>edzfrgh</li>
    <li>Kupu</li>
</ol>
<table cellspacing="1" cellpadding="1" border="1" style="width: 210px; height: 66px;">
    <tbody>
        <tr>
            <td>a</td>
            <td>b</td>
        </tr>
        <tr>
            <td>x</td>
            <td>vvv</td>
        </tr>
        <tr>
            <td>bbb</td>
            <td>vvvvv</td>
        </tr>
    </tbody>
</table>
<p>&nbsp;</p>
<p style="margin-left: 40px;">hghdghghgh</p>
<ul>
    <li>aaa</li>
    <li>&nbsp;</li>
    <li>bvbb</li>
</ul>
<ol>
    <li>regrg</li>
    <li>&nbsp;</li>
</ol>
<p>vghriqghrghgfd&nbsp; hgkll hgjkf lghjfkd slhgjfd klhgjfds klghjfds s&amp;é@èù&nbsp; vghriqghrghgfd&nbsp; hgkll hgjkf lghjfkd slhgjfd klhgjfds klghjfds s&amp;é@èù vghriqghrghgfd&nbsp; hgkll hgjkf lghjfkd slhgjfd klhgjfds klghjfds s&amp;é@èù vghriqghrghgfd&nbsp; hgkll hgjkf lghjfkd slhgjfd klhgjfds klghjfds s&amp;é@èù vghriqghrghgfd&nbsp; hgkll hgjkf lghjfkd slhgjfd klhgjfds klghjfds s&amp;é@èù vghriqghrghgfd&nbsp; hgkll hgjkf lghjfkd slhgjfd klhgjfds klghjfds s&amp;é@èù vghriqghrghgfd&nbsp; hgkll hgjkf lghjfkd slhgjfd klhgjfds klghjfds s&amp;é@èù</p>
<p>&nbsp;</p>
<p>vghriqghrghgfd&nbsp; hgkll hgjkf lghjfkd slhgjfd klhgjfds klghjfds s&amp;é@èù&nbsp; vghriqghrghgfd&nbsp; hgkll hgjkf lghjfkd slhgjfd klhgjfds klghjfds s&amp;é@èù vghriqghrghgfd&nbsp; hgkll hgjkf lghjfkd slhgjfd klhgjfds klghjfds s&amp;é@èù vghriqghrghgfd&nbsp; hgkll hgjkf lghjfkd slhgjfd klhgjfds klghjfds s&amp;é@èù vghriqghrghgfd&nbsp; hgkll hgjkf lghjfkd slhgjfd klhgjfds klghjfds s&amp;é@èù vghriqghrghgfd&nbsp; hgkll hgjkf lghjfkd slhgjfd klhgjfds klghjfds s&amp;é@èù vghriqghrghgfd&nbsp; hgkll hgjkf lghjfkd slhgjfd klhgjfds klghjfds s&amp;é@</p>
'''
