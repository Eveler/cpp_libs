# -*- coding: utf-8 -*-
xhtmlInput = '''
<p>Hello.</p>
<h2>Heading One</h2>
Blabla.<br />
<h3>SubHeading then.</h3>
Another blabla.<br /><br /><br /> '''
# I need a class.
class D:
    def getAt1(self):
        return xhtmlInput
dummy = D()
