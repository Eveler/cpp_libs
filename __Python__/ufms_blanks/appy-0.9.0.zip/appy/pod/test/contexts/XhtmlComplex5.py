# -*- coding: utf-8 -*-
xhtmlInput = '''
<p>desc 2611-03</p>
<p><br /></p>
<blockquote>
<p>identation 1</p>
<p>identation 2</p>
<p>identation 3</p>
</blockquote>
<p><br /></p>
<ol><li>point numéroté 1</li>
<ol><li>point numéroté 1.1</li><li>point numéroté 1.2</li></ol>
<li>point numéroté 2</li>
<ol><li>point numéroté 2.1</li><li>point numéroté 2.2</li><li>point numéroté 2.3</li>
<ol><li>point numéroté 2.3.1</li><li>point numéroté 2.3.2</li></ol>
</ol>
<li>point numéroté 3</li></ol>
<br />
<ul><li>grosse lune niveau 1</li>
<ul><li>grosse lune niveau 2</li>
<ul><li>grosse lune niveau 3</li>
<ul><li>grosse lune niveau 4<br /></li></ul>
</ul>
</ul>
</ul>
<ul>
<ul>
<ul>
<ul>
<ul><li>grosse lune niveau 5<br /></li>
<ul><li>grosse lune niveau 6<br /></li>
<ul><li>grosse lune niveau 7</li>
<ul><li>grosse lune niveau 8</li>
<ul><li>grosse lune niveau 9</li>
<ul><li>grosse lune niveau 10</li></ul>
</ul>
</ul>
</ul>
</ul>
</ul>
</ul>
</ul>
</ul>
</ul>
<br /><br />
<dl><dt>titre liste 1 </dt><dd>liste 1 </dd><dt>titre liste 2 </dt><dd>liste 2 </dd><dt>titre liste 3 </dt><dd>liste 3 </dd><dt>
<div align="center"><b>texte normal<br /></b></div>
</dt></dl>
<ol type="I"><li>romain maj 1</li><li>romain maj  2</li></ol>
<br />
<ol type="i"><li>romain 1</li><li>romain 2<br /></li></ol>
<dl>
<dl><dt><br /></dt></dl>
</dl>
<ol type="A"><li>alpha maj 1<br /></li><li>alpha maj 2</li></ol>
<br />
<ol type="a"><li>alpha min 1</li><li>alpha min 2</li></ol>
<br />blablabla<br />
<dl><dt><br /></dt></dl>
'''
