johnScore = 25
markScore = 53
wilsonScore = 12
meghuScore = 59

