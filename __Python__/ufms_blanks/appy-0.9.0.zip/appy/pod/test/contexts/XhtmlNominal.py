# -*- coding: utf-8 -*-
# I need a class.
class D:
    def getAt1(self):
        return '\n<p>Test1<br /></p>\n'
dummy = D()
