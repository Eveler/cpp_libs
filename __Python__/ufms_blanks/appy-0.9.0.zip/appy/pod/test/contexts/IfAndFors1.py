from appy.pod.test.contexts import Group

groups = [Group('group1'), Group('group2'), Group('toto')]
