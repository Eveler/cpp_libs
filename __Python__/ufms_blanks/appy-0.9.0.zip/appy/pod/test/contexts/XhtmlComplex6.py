# -*- coding: utf-8 -*-
xhtmlInput = '<div class="document">\n<p>Hallo?</p>\n</div>\n'
