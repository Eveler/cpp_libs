# -*- coding: utf-8 -*-
xhtmlInput = '''
<ol><li>
<p>Test du champ kupu<br />A la ligne
	1, j'y suis</p>
<ol><li>
<p>Ligne 1 de 1<br />A la ligne 1 de 1
		fdsfds fsd fsd fksdf sdfs dfd sfsd fsd fsd fdsf dsfds fsdfa azra
		zeeamr earkl kfl flks dlfksd lfklsd fklmsdfkl dskflmdsk flmsdf
		lmdsflm dflsdfs fksd fmlsd flmdsk flmdsf mlsfkmls<br />A la ligne 2
		de 1 cds fdsn sfd dsjfl dsjfhjds fhjdsf lqdhf klsfql kjfk jfkj
		qfklmqds fjdlksqfj kdlfj klqfk qfjk ljfqklq djfklqjf qfk jkfljqd
		sklfjqdklfjqdkl fjdqklf jdqlkfj qfq</p>
</li><li>
<p>Ligne 2 de 1<br />A la ligne 1 de 2
		fdsfds fsd fsd fksdf sdfs dfd sfsd fsd fsd fdsf dsfds fsdfa azra
		zeeamr earkl kfl flks dlfksd lfklsd fklmsdfkl dskflmdsk flmsdf
		lmdsflm dflsdfs fksd fmlsd flmdsk flmdsf mlsfkmls<br />A la ligne 2
		de 2 cds fdsn sfd dsjfl dsjfhjds fhjdsf lqdhf klsfql kjfk jfkj
		qfklmqds fjdlksqfj kdlfj klqfk qfjk ljfqklq djfklqjf qfk jkfljqd
		sklfjqdklfjqdkl fjdqklf jdqlkfj qf</p>
</li></ol>
</li><li>
<p>Ligne 2 tout court</p>
<ol><li>
<p>Ligne bullet dg fg dgd fgdf gdfg
		dgq fg fgfq gfqd gfqg qfg qgkqlglk lgkl fkgkfq lmgkl mfqfkglmfk
		gmlqf gmlqfgml kfmglk qmglk qmlgk qmlgkqmflgk qmlqg fmdlmslgk
		mlsgml fskfmglk gmlkflmg ksfmlgk mlsgk</p>
</li><li>
<p>dsfl kqfs dmflm dsfsdf lskfmls
		dkflmsdkf sdlmkf dslmfk sdmlfksd mlfksdmfl ksflmksdflmd slfmskd
		lsmlfk mlsdfkl mskfmlsfk lmskfsfs</p>
</li><li>
<p>fmlsdm ùfkùds fldsf ùsfsdmfù
		mdsfù msdùfms</p>
</li><li>
<p>fds fsd fdsf sdfds fsmd fmjdfklm
		sdflmkd lfqlmklmdsqkflmq dskflmkd slmgkqdfmglklfmgksmldgk
		dmlsgdkdlm fgkmdl fkgdmlfsgk mlfgksmdl fgkmldsf klmmdfkg mlsdfkgml
		skfdgml skgmlkfd smlgksd mlkgml kml</p>
</li><li>
<p>lgd ksmlgjk mlsdfgkml sdfkglm
		kdsfmlgk dlmskgsldmgk lms</p>
</li></ol>
</li><li>
<p>Ligne 3 tout court</p>
</li></ol>
<br />'''

xhtmlInput2 = '''
<ol start="1"><li>Le Gouvernement approuve la réaffectation de 20.056.989 € attribués dans le cadre du CRAC II et l’affectation du solde de 20.855.107 € du solde des CRAC Ibis et II au sein du secteur des hôpitaux de l’enveloppe de financement alternatif pour un montant total de 40.921.096 €, au bénéfice des établissements suivants :<br /><br /></li> 
<table align="center"> 
<tbody> 
<tr> 
<td> 
<b>Etablissement</b></td> 
<td> 
<p align="center" style="text-align: center;"><b>CRAC II Phase II</b></p> 
</td> 
</tr> 
<tr> 
<td> 
<p>C.H. Chrétien Liège</p> 
</td> 
<td nowrap="-1"> 
<p align="center" style="text-align: center;">11.097.377</p> 
</td> 
</tr> 
<tr> 
<td nowrap="-1"> 
<p>Hôp. St-Joseph, Ste-Thérèse et IMTR  Gilly</p> 
</td> 
<td nowrap="-1"> 
<p align="center" style="text-align: center;">8.297.880</p> 
</td> 
</tr>
</tbody> 
</table> 
<br /><li>Il prend acte des décisions du Ministre de la Santé relatives à l’octroi de la règle de 10/90 pour la subsidiation des infrastructures des établissements concernés.<br /></li>
<li>Le Gouvernement charge le Ministre de la Santé d’appliquer, le cas échéant, les nouveaux plafonds à la construction visés dans l’arrêté ministériel du 11 mai 2007 fixant le coût maximal pouvant être pris en considération pour l’octroi des subventions pour la construction de nouveaux bâtiments, les travaux d’extension et de reconditionnement d’un hôpital ou d’un service, aux demandes d’octroi de subventions antérieures au 1<sup>er</sup> janvier 2006, pour autant que ces demandes d’octroi de subventions n’aient pas encore donné lieu à l’exploitation à cette même date.<br /></li>
<li>Il charge le Ministre de la Santé de l’exécution de la présente décision</li></ol>
<p></p>
'''

xhtmlInput3 = '''
<ol><li>Le Gouvernement l'exercice 2008.</li><li>Il approuve 240.000€ de007-2008.</li><li>Le Gouvernement approuve: 
<ul><li>le projet d'arrêté ministériel 008;</li><li>le projet d'arrêté ministériel mique 2008-2009.</li></ul></li><li>Le Gouvernement charge le Ministre de l'Economie de l'exécution de la présente décision.</li></ol>
'''

xhtmlInput4 = '''
<div><strong>Programmes FSE Convergence et Compétitivité régionale et emploi.</strong></div>
<div><strong>Axe 1, mesure 1, et Axe 2, mesures 2, 3, 4 et 5 : formation.</strong></div>
<div><strong>Portefeuille de projets « Enseignement supérieur - Formation continue ».</strong></div>
'''
