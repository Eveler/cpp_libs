var1 = 'VAR1 not overridden'
var2 = 'VAR2 not overridden'
