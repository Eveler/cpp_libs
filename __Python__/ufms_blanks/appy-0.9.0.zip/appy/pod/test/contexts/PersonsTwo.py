from appy.pod.test.contexts import Person

persons = [Person('P1'), Person('P2')]
