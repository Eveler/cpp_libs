trueCondition = True
falseCondition = False

class O:
    def __init__(self, v):
        self.v = v
        self.vv = v+v

oooo = [O('a'), O('b'), O('c'), O('d')]

