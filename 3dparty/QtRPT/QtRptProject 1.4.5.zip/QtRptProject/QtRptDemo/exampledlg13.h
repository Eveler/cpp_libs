/*
Name: QtRpt
Version: 1.4.5
Programmer: Aleksey Osipov
e-mail: aliks-os@ukr.net
2012-2014
*/

#ifndef EXAMPLEDLG13_H
#define EXAMPLEDLG13_H

#include <QDialog>
#include "qtrpt.h"

namespace Ui {
    class ExampleDlg13;
}

class ExampleDlg13 : public QDialog
{
    Q_OBJECT

public:
    explicit ExampleDlg13(QWidget *parent = 0);
    ~ExampleDlg13();

private:
    Ui::ExampleDlg13 *ui;

private slots:
    void print();
    void setField(RptFieldObject &);
};

#endif // EXAMPLEDLG13_H
