/*
Name: QtRpt
Version: 1.4.1
Programmer: Aleksey Osipov
e-mail: aliks-os@yandex.ru
2012-2014
*/

#ifndef EXAMPLEDLG7_H
#define EXAMPLEDLG7_H

#include <QDialog>
#include "qtrpt.h"

namespace Ui {
class ExampleDlg7;
}

class ExampleDlg7 : public QDialog
{
    Q_OBJECT

public:
    explicit ExampleDlg7(QWidget *parent = 0);
    ~ExampleDlg7();

private:
    Ui::ExampleDlg7 *ui;
    QtRPT *report;

private slots:
    void print();
    void setValue(int &recNo, QString &paramName, QVariant &paramValue, int reportPage);
    void setValueDiagram(Chart &chart);
};

#endif // EXAMPLEDLG7_H
