/*
Name: QtRpt
Version: 1.4.5
Programmer: Aleksey Osipov
e-mail: aliks-os@yandex.ru
2012-2014
*/

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <qtrpt.h>
#include "exampledlg1.h"
#include "exampledlg2.h"
#include "exampledlg3.h"
#include "exampledlg4.h"
#include "exampledlg5.h"
#include "exampledlg6.h"
#include "exampledlg7.h"
#include "exampledlg8.h"
#include "exampledlg13.h"
#include "exampledlg14.h"
#include <CommonClasses.h>

namespace Ui {
    class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    //static void getReportValue(int &recNo, QString &paramName, QVariant &paramValue);


private:
    Ui::MainWindow *ui;


private slots:
    void showReport();
    void setValue(int &recNo, QString &paramName, QVariant &paramValue, int reportPage);

};

#endif // MAINWINDOW_H
