/*
Name: QtRpt
Version: 1.4.5
Programmer: Aleksey Osipov
e-mail: aliks-os@ukr.net
2012-2014
*/

#ifndef EXAMPLEDLG14_H
#define EXAMPLEDLG14_H

#include <QDialog>
#include "qtrpt.h"

namespace Ui {
    class ExampleDlg14;
}

class ExampleDlg14 : public QDialog
{
    Q_OBJECT

public:
    explicit ExampleDlg14(QWidget *parent = 0);
    ~ExampleDlg14();

private:
    Ui::ExampleDlg14 *ui;

private slots:
    void print();
    void setField(RptFieldObject &);
};

#endif // EXAMPLEDLG14_H
