/*
Name: QtRpt
Version: 1.4.1
Programmer: Aleksey Osipov
e-mail: aliks-os@yandex.ru
2012-2014
*/

#ifndef EXAMPLEDLG6_H
#define EXAMPLEDLG6_H

#include <QDialog>
#include "qtrpt.h"

namespace Ui {
class ExampleDlg6;
}

class ExampleDlg6 : public QDialog
{
    Q_OBJECT

public:
    explicit ExampleDlg6(QWidget *parent = 0, int mode = 1);
    ~ExampleDlg6();

private:
    Ui::ExampleDlg6 *ui;
    QtRPT *report;
    int m_mode;

private slots:
    void print();
    void setValue(int &recNo, QString &paramName, QVariant &paramValue, int reportPage);

};

#endif // EXAMPLEDLG6_H
