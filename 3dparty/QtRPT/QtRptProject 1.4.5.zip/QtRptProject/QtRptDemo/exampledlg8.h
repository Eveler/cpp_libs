/*
Name: QtRpt
Version: 1.4.1
Programmer: Aleksey Osipov
e-mail: aliks-os@yandex.ru
2012-2014
*/

#ifndef EXAMPLEDLG8_H
#define EXAMPLEDLG8_H

#include <QDialog>
#include "qtrpt.h"

namespace Ui {
class ExampleDlg8;
}

class ExampleDlg8 : public QDialog
{
    Q_OBJECT

public:
    explicit ExampleDlg8(QWidget *parent = 0);
    ~ExampleDlg8();

private:
    Ui::ExampleDlg8 *ui;
    QtRPT *report;

private slots:
    void print();
    void setValue(int &recNo, QString &paramName, QVariant &paramValue, int reportPage);

};

#endif // EXAMPLEDLG8_H
