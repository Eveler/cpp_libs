/*
Name: QtRpt
Version: 1.4.1
Programmer: Aleksey Osipov
e-mail: aliks-os@yandex.ru
2012-2014
*/

#include "exampledlg6.h"
#include "ui_exampledlg6.h"

ExampleDlg6::ExampleDlg6(QWidget *parent, int mode) :  QDialog(parent),  ui(new Ui::ExampleDlg6) {
    ui->setupUi(this);

    m_mode = mode;
    ui->tableWidget->setRowCount(27);
    QObject::connect(ui->btnPrint, SIGNAL(clicked()), this, SLOT(print()));

    QTableWidgetItem *newItem;
    for (int i = 0; i < ui->tableWidget->rowCount(); ++i) {
        switch (i){
            case 0:
            case 3:
            case 7:
            case 8:
            case 25:{
                newItem = new QTableWidgetItem("US");
                break;
            }
            case 1:
            case 9:
            case 5:
            case 14: {
                newItem = new QTableWidgetItem("Europe");
                break;
            }
            case 2:
            //case 5:
            case 10:
            case 12: {
                newItem = new QTableWidgetItem("Ukraine");
                break;
            }
            case 4:
            case 6:
            case 11:
            case 13: {
                newItem = new QTableWidgetItem("Georgia");
                break;
            }
            default: {
                newItem = new QTableWidgetItem("Other");
                break;
            }
        }

        ui->tableWidget->setItem(i,0,newItem);

        newItem = new QTableWidgetItem("Goods "+QString::number(i));
        ui->tableWidget->setItem(i,1,newItem);

        newItem = new QTableWidgetItem(QString::number(i*10));
        ui->tableWidget->setItem(i,2,newItem);

        newItem = new QTableWidgetItem(QString::number(i*100));
        ui->tableWidget->setItem(i,3,newItem);

        newItem = new QTableWidgetItem(QString::number(i*1000));
        ui->tableWidget->setItem(i,4,newItem);
    }
}

void ExampleDlg6::setValue(int &recNo, QString &paramName, QVariant &paramValue, int reportPage) {
    Q_UNUSED(reportPage);

    if ((paramName == "sampleId") && (reportPage >= 1)) {
        int id;
        if (recNo < 6) id = 1;
        else id = 2;
        QString strLeft = "Sample" + QString::number(id);
        qDebug() << "Group: " << strLeft << " " << recNo;
        paramValue = strLeft;
    }
    else if (paramName == "sNameLeft") {
        QString strLeft = "sNameLeft " + QString::number(recNo);
        paramValue = strLeft;
    }
    else if (paramName == "sNameRight") {
        QString strLeft = "sNameRight " + QString::number(recNo);
        paramValue = strLeft;
    }
    else if (paramName == "sValueLeft") {
        QString strLeft = "svalLeft " + QString::number(recNo);
        paramValue = strLeft;
    }
    else if (paramName == "sValueRight") {
        QString strLeft = "svalLeft " + QString::number(recNo);
        paramValue = strLeft;
    }
    else if (paramName == "nameLeft") {
        QString strLeft = "nameLeft " + QString::number(recNo);
        paramValue = strLeft;
    }
    else if (paramName == "nameRight") {
        QString strLeft = "nameRight " + QString::number(recNo);
        paramValue = strLeft;
    }
    else if (paramName == "valueLeft") {
        QString strLeft = "valLeft " + QString::number(recNo);
        paramValue = strLeft;
    }
    else if (paramName == "valueRight") {
        QString strLeft = "valLeft " + QString::number(recNo);
        paramValue = strLeft;
    }

    if (paramName == "Market") {
        if (ui->tableWidget->item(recNo,0) == 0) return;
        paramValue = ui->tableWidget->item(recNo,0)->text();
    }
    if (paramName == "Goods") {
        if (ui->tableWidget->item(recNo,1) == 0) return;
        paramValue = ui->tableWidget->item(recNo,1)->text();
    }
    if (paramName == "Quantity") {
        if (ui->tableWidget->item(recNo,2) == 0) return;
        paramValue = ui->tableWidget->item(recNo,2)->text();
    }
    if (paramName == "Price") {
        if (ui->tableWidget->item(recNo,3) == 0) return;
        paramValue = ui->tableWidget->item(recNo,3)->text();
    }
    if (paramName == "Sum") {
        if (ui->tableWidget->item(recNo,4) == 0) return;
        paramValue = ui->tableWidget->item(recNo,4)->text();
    }
}

void ExampleDlg6::print() {
    QString fileName;
    if (m_mode == 1)
        fileName = "./examples_report/example6a.xml";
    if (m_mode == 2)
        fileName = "./examples_report/example6b.xml";
    report = new QtRPT(this);
    report->recordCount << ui->tableWidget->rowCount();
    if (report->loadReport(fileName) == false) {
        qDebug()<<"Report's file not found";
    }
    QObject::connect(report, SIGNAL(setValue(int&, QString&, QVariant&, int)),
                     this, SLOT(setValue(int&, QString&, QVariant&, int)));
    report->printExec();
}

ExampleDlg6::~ExampleDlg6() {
    delete ui;
}

