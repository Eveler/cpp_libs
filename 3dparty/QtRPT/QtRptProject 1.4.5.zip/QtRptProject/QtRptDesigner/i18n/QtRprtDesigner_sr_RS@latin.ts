<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="sr_RS">
<context>
    <name>AboutDlg</name>
    <message>
        <location filename="../aboutDlg.cpp" line="12"/>
        <source>About QtRptDesiner</source>
        <translation>O Programu QtRptDesiner</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="29"/>
        <source>Version: </source>
        <translation>Verzija: </translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="30"/>
        <source>Programmer: Aleksey Osipov</source>
        <translation>Programer: Aleksey Osipov</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="33"/>
        <source>2012-2014 years</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="34"/>
        <source>Thanks to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="36"/>
        <source>Lukas Lalinsky for DBmodel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="37"/>
        <source>Muhamad Bashir Al-Noimi for Arabic translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="38"/>
        <source>Luis Brochado for Portuguese translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="39"/>
        <source>Li Wei for Chinese translation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditFldDlg</name>
    <message>
        <location filename="../EditFldDlg.ui" line="14"/>
        <source>Field editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="61"/>
        <source>Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="100"/>
        <source>Add variable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="103"/>
        <location filename="../EditFldDlg.ui" line="120"/>
        <location filename="../EditFldDlg.ui" line="137"/>
        <location filename="../EditFldDlg.ui" line="424"/>
        <location filename="../EditFldDlg.ui" line="655"/>
        <location filename="../EditFldDlg.ui" line="669"/>
        <location filename="../EditFldDlg.ui" line="683"/>
        <location filename="../EditFldDlg.ui" line="697"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="117"/>
        <source>Add function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="134"/>
        <source>Add formatting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="148"/>
        <source>Proccess as Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="177"/>
        <source>Attention! You may enter just ONE varibale and not any text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="185"/>
        <source>Condtion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="193"/>
        <source>Printing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="206"/>
        <source>Hightlighting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="218"/>
        <source>Condition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="235"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="241"/>
        <source>Bold</source>
        <translation type="unfinished">Podebljano</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="248"/>
        <source>Italic</source>
        <translation type="unfinished">Kurziv</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="255"/>
        <source>Underline</source>
        <translation type="unfinished">Podvučeno</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="262"/>
        <source>Strikeout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="297"/>
        <location filename="../EditFldDlg.ui" line="363"/>
        <source>Color...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="312"/>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="318"/>
        <source>Transparent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="328"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="438"/>
        <source>Ignore aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="534"/>
        <source>Diagram&apos;s property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="540"/>
        <source>Diagram</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="548"/>
        <source>Chart&apos;s caption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="560"/>
        <source>Show caption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="567"/>
        <source>Show grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="574"/>
        <source>Show legend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="581"/>
        <source>Set the params of the graphs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="588"/>
        <source>Show graph&apos;s caption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="598"/>
        <source>Graph&apos;s caption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="604"/>
        <source>Real values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="614"/>
        <source>Percent values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="641"/>
        <source>Graphs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="652"/>
        <source>Add row</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="666"/>
        <source>Remove row</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="680"/>
        <source>Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="694"/>
        <source>Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="748"/>
        <source>Caption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="753"/>
        <source>Value</source>
        <translation type="unfinished">Vrednost</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="758"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="784"/>
        <source>Barcode type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="794"/>
        <source>Frame type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="806"/>
        <source>Value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="859"/>
        <source>OK</source>
        <translation>U Redu</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="866"/>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.cpp" line="182"/>
        <location filename="../EditFldDlg.cpp" line="230"/>
        <source>Empty line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.cpp" line="182"/>
        <location filename="../EditFldDlg.cpp" line="230"/>
        <source>The field contains empty line at the end.
Remove it?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditorDelegate</name>
    <message>
        <location filename="../mainwindow.cpp" line="37"/>
        <source>Left</source>
        <translation type="unfinished">Levo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="38"/>
        <location filename="../mainwindow.cpp" line="48"/>
        <source>Center</source>
        <translation type="unfinished">Centar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="39"/>
        <source>Right</source>
        <translation type="unfinished">Desno</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="40"/>
        <source>Justify</source>
        <translation type="unfinished">Centrirano</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="47"/>
        <source>Top</source>
        <translation type="unfinished">Gore</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="49"/>
        <source>Bottom</source>
        <translation type="unfinished">Dole</translation>
    </message>
</context>
<context>
    <name>FldPropertyDlg</name>
    <message>
        <location filename="../FldPropertyDlg.ui" line="14"/>
        <source>Expression editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="66"/>
        <source>Data filed grouping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="78"/>
        <source>Start line numeration for each group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="88"/>
        <source>Start new page for each group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="114"/>
        <source>Category</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="121"/>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="132"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="146"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="167"/>
        <source>Precision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="198"/>
        <source>Format string</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="212"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="243"/>
        <source>OK</source>
        <translation type="unfinished">U Redu</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="250"/>
        <source>Cancel</source>
        <translation type="unfinished">Odustani</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="38"/>
        <location filename="../FldPropertyDlg.cpp" line="71"/>
        <source>Variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="39"/>
        <source>System variables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="75"/>
        <location filename="../FldPropertyDlg.cpp" line="96"/>
        <source>Functions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="76"/>
        <source>Aggregate functions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ItemPropertyDlg</name>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="14"/>
        <source>Object property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="44"/>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="78"/>
        <source>Name</source>
        <translation type="unfinished">Ime</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="105"/>
        <source>Relation property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="128"/>
        <source>Parent table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="145"/>
        <source>Columns:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="159"/>
        <source>reference</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="166"/>
        <source>Child table</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="208"/>
        <source>OK</source>
        <translation type="unfinished">U Redu</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="215"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <source>QtRPT Designer</source>
        <translation>QtRPT Designer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="152"/>
        <location filename="../mainwindow.cpp" line="1993"/>
        <location filename="../mainwindow.cpp" line="2157"/>
        <source>Name</source>
        <translation>Ime</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="157"/>
        <source>Value</source>
        <translation>Vrednost</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="181"/>
        <source>File</source>
        <translation>Datoteka</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="195"/>
        <location filename="../mainwindow.cpp" line="292"/>
        <source>Report</source>
        <translation>Izveštaj</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="201"/>
        <source>Edit</source>
        <translation>Uređivanje</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="212"/>
        <source>Help</source>
        <translation>Pomoć</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="272"/>
        <source>toolBar</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="220"/>
        <source>Service</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="310"/>
        <source>toolBar_2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="321"/>
        <source>toolBar_3</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="341"/>
        <location filename="../mainwindow.ui" line="344"/>
        <source>Exit</source>
        <translation>Izlaz</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="353"/>
        <source>Page settings</source>
        <translation>Podešavanje strane</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="365"/>
        <location filename="../mainwindow.ui" line="368"/>
        <source>Select tool</source>
        <translation>Alat za selekciju</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="380"/>
        <location filename="../mainwindow.ui" line="383"/>
        <source>Align left</source>
        <translation>Poravnaj levo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="395"/>
        <location filename="../mainwindow.ui" line="398"/>
        <source>Align center</source>
        <translation>Poravnaj centar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="410"/>
        <location filename="../mainwindow.ui" line="413"/>
        <source>Align right</source>
        <translation>Poravnaj desno</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="425"/>
        <location filename="../mainwindow.ui" line="428"/>
        <location filename="../mainwindow.cpp" line="2018"/>
        <source>Justify</source>
        <translation>Centrirano</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="440"/>
        <location filename="../mainwindow.ui" line="443"/>
        <location filename="../mainwindow.cpp" line="2179"/>
        <source>Bold</source>
        <translation>Podebljano</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="455"/>
        <location filename="../mainwindow.ui" line="458"/>
        <location filename="../mainwindow.cpp" line="2189"/>
        <source>Italic</source>
        <translation>Kurziv</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="470"/>
        <location filename="../mainwindow.ui" line="473"/>
        <location filename="../mainwindow.cpp" line="2199"/>
        <source>Underline</source>
        <translation>Podvučeno</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="485"/>
        <location filename="../mainwindow.ui" line="488"/>
        <source>Top line</source>
        <translation>Gornja linija</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="500"/>
        <location filename="../mainwindow.ui" line="503"/>
        <source>Bottom line</source>
        <translation>Donja linija</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="515"/>
        <location filename="../mainwindow.ui" line="518"/>
        <source>Left line</source>
        <translation>Leva linija</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="530"/>
        <location filename="../mainwindow.ui" line="533"/>
        <source>Right line</source>
        <translation>Desna linija</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="545"/>
        <location filename="../mainwindow.ui" line="548"/>
        <source>All frame line</source>
        <translation>Sve linije</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="560"/>
        <location filename="../mainwindow.ui" line="563"/>
        <source>No frame</source>
        <translation>Bez okvira</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="575"/>
        <location filename="../mainwindow.ui" line="578"/>
        <source>Insert band</source>
        <translation>Ubaci grupu</translation>
    </message>
    <message>
        <source>Add filed</source>
        <translation type="obsolete">Dodaj polje</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="593"/>
        <source>Add Fleld</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="596"/>
        <source>Add field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="605"/>
        <location filename="../mainwindow.ui" line="608"/>
        <source>New report</source>
        <translation>Nov izveštaj</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="617"/>
        <location filename="../mainwindow.ui" line="620"/>
        <source>Open report</source>
        <translation>Otvori izveštaj</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="623"/>
        <source>Ctrl+O</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="635"/>
        <location filename="../mainwindow.ui" line="638"/>
        <source>Save report</source>
        <translation>Snimi izveštaj</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="641"/>
        <source>Ctrl+S</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="653"/>
        <location filename="../mainwindow.ui" line="656"/>
        <source>Align top</source>
        <translation>Poravnaj gore</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="668"/>
        <location filename="../mainwindow.ui" line="671"/>
        <source>Align V center</source>
        <translation>Poravnaj V centar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="683"/>
        <location filename="../mainwindow.ui" line="686"/>
        <source>Align bottom</source>
        <translation>Poravnaj dole</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="695"/>
        <location filename="../mainwindow.ui" line="698"/>
        <source>Copy</source>
        <translation>Kopiraj</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="701"/>
        <source>Ctrl+C</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="710"/>
        <location filename="../mainwindow.ui" line="713"/>
        <source>Cut</source>
        <translation>Iseci</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="716"/>
        <source>Ctrl+X</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="728"/>
        <location filename="../mainwindow.ui" line="731"/>
        <source>Paste</source>
        <translation>Ubaci</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="734"/>
        <source>Ctrl+V</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="743"/>
        <location filename="../mainwindow.ui" line="746"/>
        <source>Save as</source>
        <translation>Snimi kao</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="755"/>
        <location filename="../mainwindow.ui" line="758"/>
        <source>Font color</source>
        <translation>Boja fonta</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="767"/>
        <location filename="../mainwindow.ui" line="770"/>
        <source>Background color</source>
        <translation>Pozadinska boja</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="779"/>
        <location filename="../mainwindow.ui" line="782"/>
        <source>Border color</source>
        <translation>Boja ivice</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="791"/>
        <source>About QtRptDesigner</source>
        <translation>O Programu QtRptDesiner</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="803"/>
        <source>Show Grid</source>
        <translation>Prikaži mrežu</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="806"/>
        <source>Show/Hide grid</source>
        <translation>Prikaži/Sakrij mrežu</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="821"/>
        <source>Add picture</source>
        <translation>Dodaj sliku</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="830"/>
        <location filename="../mainwindow.ui" line="833"/>
        <source>Frame style</source>
        <translation>Stil frejma</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="842"/>
        <location filename="../mainwindow.ui" line="845"/>
        <source>New Report Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="854"/>
        <location filename="../mainwindow.ui" line="857"/>
        <source>Delete Report Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="866"/>
        <location filename="../mainwindow.ui" line="869"/>
        <source>Align Field Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="878"/>
        <location filename="../mainwindow.ui" line="881"/>
        <source>Align Field Middle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="890"/>
        <location filename="../mainwindow.ui" line="893"/>
        <source>Align Field Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="902"/>
        <location filename="../mainwindow.ui" line="905"/>
        <source>Align Field Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="914"/>
        <location filename="../mainwindow.ui" line="917"/>
        <source>Align Field Center</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="926"/>
        <location filename="../mainwindow.ui" line="929"/>
        <source>Align Field Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="938"/>
        <location filename="../mainwindow.ui" line="941"/>
        <source>Field Same Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="950"/>
        <location filename="../mainwindow.ui" line="953"/>
        <source>Field Same Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="962"/>
        <location filename="../mainwindow.ui" line="965"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="977"/>
        <location filename="../mainwindow.ui" line="980"/>
        <source>Magnifying glass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="992"/>
        <location filename="../mainwindow.ui" line="995"/>
        <location filename="../mainwindow.cpp" line="2209"/>
        <source>Strikeout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1004"/>
        <location filename="../mainwindow.ui" line="1007"/>
        <source>Group property</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1012"/>
        <location filename="../mainwindow.ui" line="1015"/>
        <source>Check updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1027"/>
        <location filename="../mainwindow.ui" line="1030"/>
        <source>Add Diagram</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1045"/>
        <location filename="../mainwindow.ui" line="1048"/>
        <source>Add Drawing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1060"/>
        <location filename="../mainwindow.ui" line="1063"/>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1075"/>
        <location filename="../mainwindow.ui" line="1078"/>
        <source>Data Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1090"/>
        <location filename="../mainwindow.ui" line="1093"/>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1096"/>
        <source>Ctrl+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1108"/>
        <location filename="../mainwindow.ui" line="1111"/>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1114"/>
        <source>Ctrl+Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1126"/>
        <location filename="../mainwindow.ui" line="1129"/>
        <source>Add Barcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1134"/>
        <location filename="../mainwindow.ui" line="1137"/>
        <source>Readme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1149"/>
        <location filename="../mainwindow.ui" line="1152"/>
        <source>Add Rich Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="260"/>
        <source>Frame width</source>
        <translation>Širina frejma</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="396"/>
        <source>Report Title</source>
        <translation>Naslov izveštaja</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="402"/>
        <source>Report Summary</source>
        <translation>Rezime izveštaja</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="408"/>
        <source>Page Header</source>
        <translation>Zaglavlje</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="414"/>
        <source>Page Footer</source>
        <translation>Fusnota</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="420"/>
        <source>Master Data</source>
        <translation>Glavni Podaci</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="446"/>
        <location filename="../mainwindow.cpp" line="2384"/>
        <source>Master Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="440"/>
        <location filename="../mainwindow.cpp" line="2388"/>
        <source>Master Header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="218"/>
        <source>Font name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="221"/>
        <source>Font size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="246"/>
        <source>Zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="426"/>
        <source>Data Grouping Header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="433"/>
        <source>Data Grouping Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="496"/>
        <source>Line with arrows at both side</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="502"/>
        <source>Rectangle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="508"/>
        <source>Rounded rectangle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="514"/>
        <source>Ellipse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="520"/>
        <source>Triangle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="526"/>
        <source>Rhombus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="620"/>
        <source>&amp;%1 %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="773"/>
        <location filename="../mainwindow.cpp" line="1020"/>
        <source>Page %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="952"/>
        <location filename="../mainwindow.cpp" line="964"/>
        <location filename="../mainwindow.cpp" line="1715"/>
        <location filename="../mainwindow.cpp" line="2507"/>
        <source>Saving</source>
        <translation type="unfinished">Snimanje</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="952"/>
        <location filename="../mainwindow.cpp" line="964"/>
        <location filename="../mainwindow.cpp" line="1715"/>
        <location filename="../mainwindow.cpp" line="2507"/>
        <source>The report was changed.
Save the report?</source>
        <translation type="unfinished">Izveštaj je izmenjen.
Snimi izveštaj?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="980"/>
        <source>Select File</source>
        <translation type="unfinished">Izaberi Datoteku</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1422"/>
        <source>Save File</source>
        <translation type="unfinished">Snimi Datoteku</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1422"/>
        <source>XML Files (*.xml)</source>
        <translation type="unfinished">XML Datoteke (*.xml)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1999"/>
        <source>Aligment hor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2003"/>
        <location filename="../mainwindow.cpp" line="2064"/>
        <location filename="../mainwindow.cpp" line="2093"/>
        <source>Left</source>
        <translation type="unfinished">Levo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2008"/>
        <location filename="../mainwindow.cpp" line="2036"/>
        <source>Center</source>
        <translation type="unfinished">Centar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2013"/>
        <location filename="../mainwindow.cpp" line="2103"/>
        <source>Right</source>
        <translation type="unfinished">Desno</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="478"/>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="484"/>
        <source>Line with arrow at the end</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="490"/>
        <source>Line with arrow at the start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1436"/>
        <location filename="../mainwindow.cpp" line="2650"/>
        <source>Error</source>
        <translation type="unfinished">Greška</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1643"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1651"/>
        <source>Frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2027"/>
        <source>Aligment ver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2031"/>
        <location filename="../mainwindow.cpp" line="2077"/>
        <location filename="../mainwindow.cpp" line="2113"/>
        <source>Top</source>
        <translation type="unfinished">Gore</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2041"/>
        <location filename="../mainwindow.cpp" line="2123"/>
        <source>Bottom</source>
        <translation type="unfinished">Dole</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2050"/>
        <source>Height</source>
        <translation type="unfinished">Visina</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2057"/>
        <source>Width</source>
        <translation type="unfinished">Širina</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2071"/>
        <source>Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2147"/>
        <source>FrameWidth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2167"/>
        <source>Size</source>
        <translation type="unfinished">Veličina</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2216"/>
        <source>Printing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2222"/>
        <source>Start New Numeration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2228"/>
        <source>Show In Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2234"/>
        <source>Start New Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2240"/>
        <source>AutoHeight</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2246"/>
        <source>IgnoreRatioAspect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2252"/>
        <source>ArrowStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2258"/>
        <source>ArrowEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2264"/>
        <source>BackgroundColor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2270"/>
        <source>BorderColor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2279"/>
        <source>FontColor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2285"/>
        <source>BarcodeType</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2291"/>
        <source>BarcodeFrameType</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2364"/>
        <source>Report title</source>
        <translation type="unfinished">Naslov Izveštaja</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2368"/>
        <source>Report summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2372"/>
        <source>Page header</source>
        <translation type="unfinished">Zaglavlje</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2376"/>
        <source>Page footer</source>
        <translation type="unfinished">Fusnota</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2380"/>
        <source>Master data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2392"/>
        <source>Data Group Header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2396"/>
        <source>Data Group Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2650"/>
        <source>This object %1 can&apos;t be a parent for %2</source>
        <translation type="unfinished">Objekat %1 ne može biti roditelj objektu %2</translation>
    </message>
</context>
<context>
    <name>PageSettingDlg</name>
    <message>
        <location filename="../PageSettingDlg.ui" line="32"/>
        <source>Page settings</source>
        <translation>Podešavanje stranice</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="42"/>
        <source>Size</source>
        <translation>Veličina</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="51"/>
        <source>A4</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="56"/>
        <source>Letter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="64"/>
        <source>Width</source>
        <translation>Širina</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="74"/>
        <location filename="../PageSettingDlg.ui" line="91"/>
        <location filename="../PageSettingDlg.ui" line="174"/>
        <location filename="../PageSettingDlg.ui" line="191"/>
        <location filename="../PageSettingDlg.ui" line="208"/>
        <location filename="../PageSettingDlg.ui" line="225"/>
        <source>cm</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="81"/>
        <source>Height</source>
        <translation>Visina</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="116"/>
        <source>Orientation</source>
        <translation>Orijentacija</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="124"/>
        <source>Portrait</source>
        <translation>Uspravno</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="134"/>
        <source>Landscape</source>
        <translation>Položeno</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="156"/>
        <source>Margins</source>
        <translation>Margine</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="164"/>
        <source>Left</source>
        <translation>Levo</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="181"/>
        <source>Right</source>
        <translation>Desno</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="198"/>
        <source>Top</source>
        <translation>Gore</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="215"/>
        <source>Bottom</source>
        <translation>Dole</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="265"/>
        <source>OK</source>
        <translation>U Redu</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="272"/>
        <source>Cancel</source>
        <translation>Odustani</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.cpp" line="29"/>
        <source>Cm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.cpp" line="32"/>
        <source>Inch</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../main.cpp" line="14"/>
        <source>QtRptDesigner</source>
        <translation>QtRptDesigner</translation>
    </message>
</context>
<context>
    <name>QTextEditEx</name>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="43"/>
        <source>Cut</source>
        <translation type="unfinished">Iseci</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="46"/>
        <location filename="../../CommonFiles/qtexteditex.ui" line="63"/>
        <location filename="../../CommonFiles/qtexteditex.ui" line="80"/>
        <location filename="../../CommonFiles/qtexteditex.ui" line="113"/>
        <location filename="../../CommonFiles/qtexteditex.ui" line="133"/>
        <location filename="../../CommonFiles/qtexteditex.ui" line="153"/>
        <location filename="../../CommonFiles/qtexteditex.ui" line="189"/>
        <location filename="../../CommonFiles/qtexteditex.ui" line="209"/>
        <location filename="../../CommonFiles/qtexteditex.ui" line="229"/>
        <location filename="../../CommonFiles/qtexteditex.ui" line="249"/>
        <location filename="../../CommonFiles/qtexteditex.ui" line="308"/>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="60"/>
        <source>Copy</source>
        <translation type="unfinished">Kopiraj</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="77"/>
        <source>Paste</source>
        <translation type="unfinished">Ubaci</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="110"/>
        <source>Bold</source>
        <translation type="unfinished">Podebljano</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="130"/>
        <source>Italic</source>
        <translation type="unfinished">Kurziv</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="150"/>
        <source>Underline</source>
        <translation type="unfinished">Podvučeno</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="186"/>
        <source>Align left</source>
        <translation type="unfinished">Poravnaj levo</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="206"/>
        <source>Align center</source>
        <translation type="unfinished">Poravnaj centar</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="226"/>
        <source>Align right</source>
        <translation type="unfinished">Poravnaj desno</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="246"/>
        <source>Align jusify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="282"/>
        <source>List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="305"/>
        <source>Font color</source>
        <translation type="unfinished">Boja fonta</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="322"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="332"/>
        <source>Font size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.cpp" line="47"/>
        <source>Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.cpp" line="48"/>
        <source>Bullet List (Disc)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.cpp" line="49"/>
        <source>Bullet List (Circle)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.cpp" line="50"/>
        <source>Bullet List (Square)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.cpp" line="51"/>
        <source>Ordered List (Decimal)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.cpp" line="52"/>
        <source>Ordered List (Alpha lower)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.cpp" line="53"/>
        <source>Ordered List (Alpha upper)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ReportBand</name>
    <message>
        <location filename="../ReportBand.cpp" line="49"/>
        <source>Report title</source>
        <translation>Naslov Izveštaja</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="55"/>
        <source>Report summary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="61"/>
        <source>Page header</source>
        <translation>Zaglavlje</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="67"/>
        <source>Page footer</source>
        <translation>Fusnota</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="73"/>
        <source>Master band</source>
        <translation>Glavni Podaci</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="80"/>
        <source>Master footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="86"/>
        <source>Master header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="92"/>
        <source>Data Group Header</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="98"/>
        <source>Data Group Footer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="118"/>
        <source>Delete</source>
        <translation>Obriši</translation>
    </message>
</context>
<context>
    <name>SettingDlg</name>
    <message>
        <location filename="../SettingDlg.ui" line="14"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="24"/>
        <source>Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="66"/>
        <source>Grid&apos;s step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="32"/>
        <source>Measurement&apos;s unit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="42"/>
        <source>Cm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="55"/>
        <source>Inch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="85"/>
        <source>Show grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="95"/>
        <source>Internationalization</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="103"/>
        <source>Language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="111"/>
        <source>System Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="116"/>
        <source>Arabic عربي</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="121"/>
        <source>American English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="126"/>
        <source>Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="131"/>
        <source>Georgian ქართული</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="136"/>
        <source>Portuguese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="141"/>
        <source>Russian Русский</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="156"/>
        <source>Ukraine Український</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="146"/>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="151"/>
        <source>Serbian Latin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="169"/>
        <source>Check updates during start application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="191"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="198"/>
        <source>Cancel</source>
        <translation type="unfinished">Odustani</translation>
    </message>
    <message>
        <location filename="../SettingDlg.cpp" line="111"/>
        <source>Message QtRptDesigner</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.cpp" line="111"/>
        <source>The language for this application has been changed.
The change will take effect the next time the application is started.
Restart application?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SqlDesigner</name>
    <message>
        <location filename="../SqlDesigner.ui" line="34"/>
        <source>Custom DS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="44"/>
        <source>SQL DS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="121"/>
        <source>Driver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="156"/>
        <source>QSQLITE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="98"/>
        <source>Connection&apos;s parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="161"/>
        <source>QMYSQL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="166"/>
        <source>QMYSQL3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="171"/>
        <source>QODBC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="176"/>
        <source>QODBC3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="181"/>
        <source>QPSQL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="186"/>
        <source>QPSQL7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="322"/>
        <location filename="../SqlDesigner.ui" line="325"/>
        <source>Clear diagram</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="340"/>
        <location filename="../SqlDesigner.ui" line="343"/>
        <source>Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="352"/>
        <location filename="../SqlDesigner.ui" line="355"/>
        <source>Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="358"/>
        <source>Ctrl+Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="367"/>
        <location filename="../SqlDesigner.ui" line="370"/>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="373"/>
        <source>Ctrl+Z</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="385"/>
        <location filename="../SqlDesigner.ui" line="388"/>
        <source>Add relationship</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="397"/>
        <location filename="../SqlDesigner.ui" line="400"/>
        <source>Delete</source>
        <translation type="unfinished">Obriši</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="403"/>
        <source>Del</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="148"/>
        <source>Connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="128"/>
        <source>Check</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="218"/>
        <source>DB name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="211"/>
        <source>User name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="104"/>
        <source>Host name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="201"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="135"/>
        <source>Connection coding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="114"/>
        <location filename="../SqlDesigner.ui" line="225"/>
        <source>UTF8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="194"/>
        <source>Charset coding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="297"/>
        <source>SQL query</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="81"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.cpp" line="83"/>
        <source>Error</source>
        <translation type="unfinished">Greška</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.cpp" line="86"/>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SqlDesigner.cpp" line="86"/>
        <source>Connected</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TContainerField</name>
    <message>
        <location filename="../TContainerField.cpp" line="43"/>
        <source>Edit</source>
        <translation>Uređivanje</translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="47"/>
        <source>Delete</source>
        <translation>Obriši</translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="54"/>
        <source>Move forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="60"/>
        <source>Move back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="235"/>
        <source>New image</source>
        <translation type="unfinished">Nova slika</translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="242"/>
        <source>New diagram</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TContainerLine</name>
    <message>
        <location filename="../TContainerLine.cpp" line="228"/>
        <source>Delete</source>
        <translation type="unfinished">Obriši</translation>
    </message>
</context>
<context>
    <name>UpdateDlg</name>
    <message>
        <location filename="../../CommonFiles/updatedlg.ui" line="14"/>
        <location filename="../../CommonFiles/updatedlg.ui" line="38"/>
        <source>Updating</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/updatedlg.ui" line="33"/>
        <source>Progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/updatedlg.ui" line="82"/>
        <source>Update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/updatedlg.ui" line="89"/>
        <source>Cancel</source>
        <translation type="unfinished">Odustani</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/updatedlg.cpp" line="30"/>
        <source>Open Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/updatedlg.cpp" line="53"/>
        <source>Downloading %0. ..</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
