<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="pt_PT">
<context>
    <name>AboutDlg</name>
    <message>
        <location filename="../aboutDlg.cpp" line="12"/>
        <source>About QtRptDesiner</source>
        <translation>Acerca do QtRptDesigner</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="29"/>
        <source>Version: </source>
        <translation>Versão:</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="30"/>
        <source>Programmer: Aleksey Osipov</source>
        <translation>Programador: Aleksey Osipov</translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="33"/>
        <source>2012-2014 years</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="34"/>
        <source>Thanks to:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="36"/>
        <source>Lukas Lalinsky for DBmodel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="37"/>
        <source>Muhamad Bashir Al-Noimi for Arabic translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="38"/>
        <source>Luis Brochado for Portuguese translation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutDlg.cpp" line="39"/>
        <source>Li Wei for Chinese translation</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EditFldDlg</name>
    <message>
        <location filename="../EditFldDlg.ui" line="14"/>
        <source>Field editor</source>
        <translation>Editor de Campo</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="61"/>
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="100"/>
        <source>Add variable</source>
        <translation>Adicionar variável</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="103"/>
        <location filename="../EditFldDlg.ui" line="120"/>
        <location filename="../EditFldDlg.ui" line="137"/>
        <location filename="../EditFldDlg.ui" line="424"/>
        <location filename="../EditFldDlg.ui" line="655"/>
        <location filename="../EditFldDlg.ui" line="669"/>
        <location filename="../EditFldDlg.ui" line="683"/>
        <location filename="../EditFldDlg.ui" line="697"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="117"/>
        <source>Add function</source>
        <translation>Adicionar função</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="134"/>
        <source>Add formatting</source>
        <translation>Adicionar formatação</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="148"/>
        <source>Proccess as Image</source>
        <translation>Processar como Imagem</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="177"/>
        <source>Attention! You may enter just ONE varibale and not any text.</source>
        <translation>Atenção! Apenas introduzir UMA variável e nenhum texto.</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="185"/>
        <source>Condtion</source>
        <translation>Condição</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="193"/>
        <source>Printing</source>
        <translation>Imprimindo</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="206"/>
        <source>Hightlighting</source>
        <translation>Realçando</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="218"/>
        <source>Condition</source>
        <translation>Condição</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="235"/>
        <source>Font</source>
        <translation>Tipo de Letra</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="241"/>
        <source>Bold</source>
        <translation>Negrito</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="248"/>
        <source>Italic</source>
        <translation>Itálico</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="255"/>
        <source>Underline</source>
        <translation>Sublinhado</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="262"/>
        <source>Strikeout</source>
        <translation>Rasurado</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="297"/>
        <location filename="../EditFldDlg.ui" line="363"/>
        <source>Color...</source>
        <translation>Cor...</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="312"/>
        <source>Background</source>
        <translation>Fundo</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="318"/>
        <source>Transparent</source>
        <translation>Transparente</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="328"/>
        <source>Other</source>
        <translation>Outros</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="438"/>
        <source>Ignore aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="534"/>
        <source>Diagram&apos;s property</source>
        <translation>Propriedades do Diagrama</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="540"/>
        <source>Diagram</source>
        <translation>Diagrama</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="548"/>
        <source>Chart&apos;s caption</source>
        <translation>Título da Tabela</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="560"/>
        <source>Show caption</source>
        <translation>Mostrar título</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="567"/>
        <source>Show grid</source>
        <translation>Mostrar grelha</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="574"/>
        <source>Show legend</source>
        <translation>Mostrar legenda</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="581"/>
        <source>Set the params of the graphs</source>
        <translation>Definir parâmetros do grafico</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="588"/>
        <source>Show graph&apos;s caption</source>
        <translation>Mostrar título do grafico</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="598"/>
        <source>Graph&apos;s caption</source>
        <translation>Título do Grafico</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="604"/>
        <source>Real values</source>
        <translation>Valores Reais</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="614"/>
        <source>Percent values</source>
        <translation>Valores Percentuais</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="641"/>
        <source>Graphs</source>
        <translation>Graficos</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="652"/>
        <source>Add row</source>
        <translation>Adicionar linha</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="666"/>
        <source>Remove row</source>
        <translation>Remover linha</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="680"/>
        <source>Up</source>
        <translation>Cima</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="694"/>
        <source>Down</source>
        <translation>Baixo</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="748"/>
        <source>Caption</source>
        <translation>Título</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="753"/>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="758"/>
        <source>Color</source>
        <translation>Cor</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="784"/>
        <source>Barcode type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="794"/>
        <source>Frame type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="806"/>
        <source>Value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="859"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.ui" line="866"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.cpp" line="182"/>
        <location filename="../EditFldDlg.cpp" line="230"/>
        <source>Empty line</source>
        <translation>Linha vazia</translation>
    </message>
    <message>
        <location filename="../EditFldDlg.cpp" line="182"/>
        <location filename="../EditFldDlg.cpp" line="230"/>
        <source>The field contains empty line at the end.
Remove it?</source>
        <translation>O campo contêm uma linha vazia no final
Remove-la?</translation>
    </message>
</context>
<context>
    <name>EditorDelegate</name>
    <message>
        <location filename="../mainwindow.cpp" line="37"/>
        <source>Left</source>
        <translation type="unfinished">Esquerda</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="38"/>
        <location filename="../mainwindow.cpp" line="48"/>
        <source>Center</source>
        <translation type="unfinished">Centro</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="39"/>
        <source>Right</source>
        <translation type="unfinished">Direita</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="40"/>
        <source>Justify</source>
        <translation type="unfinished">Justificado</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="47"/>
        <source>Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="49"/>
        <source>Bottom</source>
        <translation type="unfinished">Fundo</translation>
    </message>
</context>
<context>
    <name>FldPropertyDlg</name>
    <message>
        <location filename="../FldPropertyDlg.ui" line="14"/>
        <source>Expression editor</source>
        <translation>Editor de expressões</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="66"/>
        <source>Data filed grouping</source>
        <translation>Agrupamento de campos de dados</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="78"/>
        <source>Start line numeration for each group</source>
        <translation>Iniciar numeração de linha para cada grupo</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="88"/>
        <source>Start new page for each group</source>
        <translation>Criar nova pagina para cada grupo</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="114"/>
        <source>Category</source>
        <translation>Categoria</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="121"/>
        <source>Number</source>
        <translation>Numero</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="132"/>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="146"/>
        <source>Other</source>
        <translation>Outro</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="167"/>
        <source>Precision</source>
        <translation>Precisão</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="198"/>
        <source>Format string</source>
        <translation>Formatação de string</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="212"/>
        <source>Clear</source>
        <translation>Limpar</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="243"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.ui" line="250"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="38"/>
        <location filename="../FldPropertyDlg.cpp" line="71"/>
        <source>Variables</source>
        <translation>Variáveis</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="39"/>
        <source>System variables</source>
        <translation>Variáveis de Sistema</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="75"/>
        <location filename="../FldPropertyDlg.cpp" line="96"/>
        <source>Functions</source>
        <translation>Funções</translation>
    </message>
    <message>
        <location filename="../FldPropertyDlg.cpp" line="76"/>
        <source>Aggregate functions</source>
        <translation>Agregar funções</translation>
    </message>
</context>
<context>
    <name>ItemPropertyDlg</name>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="14"/>
        <source>Object property</source>
        <translation>Propriedades do Objecto</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="44"/>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="78"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="105"/>
        <source>Relation property</source>
        <translation>Propriedades da Relação</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="128"/>
        <source>Parent table</source>
        <translation>Tabela Pai</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="145"/>
        <source>Columns:</source>
        <translation>Colunas:</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="159"/>
        <source>reference</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="166"/>
        <source>Child table</source>
        <translation>Tabela filho</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="208"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../SQLDiagram/ItemPropertyDlg.ui" line="215"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../mainwindow.ui" line="14"/>
        <source>QtRPT Designer</source>
        <translation>QtRPT Designer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="152"/>
        <location filename="../mainwindow.cpp" line="1993"/>
        <location filename="../mainwindow.cpp" line="2157"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="157"/>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="181"/>
        <source>File</source>
        <translation>Ficheiro</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="195"/>
        <location filename="../mainwindow.cpp" line="292"/>
        <source>Report</source>
        <translation>Report</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="201"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="212"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="220"/>
        <source>Service</source>
        <translation>Serviço</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="272"/>
        <source>toolBar</source>
        <translation>Barra de Ferramentas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="310"/>
        <source>toolBar_2</source>
        <translation>Barra de Ferramentas 2</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="321"/>
        <source>toolBar_3</source>
        <translation>Barra de Ferramentas 3</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="341"/>
        <location filename="../mainwindow.ui" line="344"/>
        <source>Exit</source>
        <translation>Sair</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="353"/>
        <source>Page settings</source>
        <translation>Definições de Pagina</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="365"/>
        <location filename="../mainwindow.ui" line="368"/>
        <source>Select tool</source>
        <translation>Selecionar ferramenta</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="380"/>
        <location filename="../mainwindow.ui" line="383"/>
        <source>Align left</source>
        <translation>Alinhar à esquerda</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="395"/>
        <location filename="../mainwindow.ui" line="398"/>
        <source>Align center</source>
        <translation>Alinhar ao centro</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="410"/>
        <location filename="../mainwindow.ui" line="413"/>
        <source>Align right</source>
        <translation>Alinhar à direita</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="425"/>
        <location filename="../mainwindow.ui" line="428"/>
        <location filename="../mainwindow.cpp" line="2018"/>
        <source>Justify</source>
        <translation>Justificado</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="440"/>
        <location filename="../mainwindow.ui" line="443"/>
        <location filename="../mainwindow.cpp" line="2179"/>
        <source>Bold</source>
        <translation>Negrito</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="455"/>
        <location filename="../mainwindow.ui" line="458"/>
        <location filename="../mainwindow.cpp" line="2189"/>
        <source>Italic</source>
        <translation>Itálico</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="470"/>
        <location filename="../mainwindow.ui" line="473"/>
        <location filename="../mainwindow.cpp" line="2199"/>
        <source>Underline</source>
        <translation>Sublinhado</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="485"/>
        <location filename="../mainwindow.ui" line="488"/>
        <source>Top line</source>
        <translation>Linha superior</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="500"/>
        <location filename="../mainwindow.ui" line="503"/>
        <source>Bottom line</source>
        <translation>Linha inferior</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="515"/>
        <location filename="../mainwindow.ui" line="518"/>
        <source>Left line</source>
        <translation>Linha esquerda</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="530"/>
        <location filename="../mainwindow.ui" line="533"/>
        <source>Right line</source>
        <translation>Linha direita</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="545"/>
        <location filename="../mainwindow.ui" line="548"/>
        <source>All frame line</source>
        <translation>Todas as linhas</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="560"/>
        <location filename="../mainwindow.ui" line="563"/>
        <source>No frame</source>
        <translation>Sem caixilho</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="575"/>
        <location filename="../mainwindow.ui" line="578"/>
        <source>Insert band</source>
        <translation>Inserir banda</translation>
    </message>
    <message>
        <source>Add Filed</source>
        <translatorcomment>filed or field?i assume field</translatorcomment>
        <translation type="vanished">Adicionar Campo</translation>
    </message>
    <message>
        <source>Add filed</source>
        <translatorcomment>filed or field?i assume field</translatorcomment>
        <translation type="vanished">Adicionar campo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="593"/>
        <source>Add Fleld</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="596"/>
        <source>Add field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="605"/>
        <location filename="../mainwindow.ui" line="608"/>
        <source>New report</source>
        <translation>Novo report</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="617"/>
        <location filename="../mainwindow.ui" line="620"/>
        <source>Open report</source>
        <translation>Abrir report</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="623"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="635"/>
        <location filename="../mainwindow.ui" line="638"/>
        <source>Save report</source>
        <translation>Guardar report</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="641"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="653"/>
        <location filename="../mainwindow.ui" line="656"/>
        <source>Align top</source>
        <translation>Alinhar ao topo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="668"/>
        <location filename="../mainwindow.ui" line="671"/>
        <source>Align V center</source>
        <translation>Alinhar V centro</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="683"/>
        <location filename="../mainwindow.ui" line="686"/>
        <source>Align bottom</source>
        <translation>Alinhar ao.fundo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="695"/>
        <location filename="../mainwindow.ui" line="698"/>
        <source>Copy</source>
        <translation>Copiar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="701"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="710"/>
        <location filename="../mainwindow.ui" line="713"/>
        <source>Cut</source>
        <translation>Cortar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="716"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="728"/>
        <location filename="../mainwindow.ui" line="731"/>
        <source>Paste</source>
        <translation>Colar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="734"/>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="743"/>
        <location filename="../mainwindow.ui" line="746"/>
        <source>Save as</source>
        <translation>Guardar como</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="755"/>
        <location filename="../mainwindow.ui" line="758"/>
        <source>Font color</source>
        <translation>Cor do Tipo de Letra</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="767"/>
        <location filename="../mainwindow.ui" line="770"/>
        <source>Background color</source>
        <translation>Cor de fundo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="779"/>
        <location filename="../mainwindow.ui" line="782"/>
        <source>Border color</source>
        <translation>Cor do contorno</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="791"/>
        <source>About QtRptDesigner</source>
        <translation>Acerca do QtRptDesigner</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="803"/>
        <source>Show Grid</source>
        <translation>Mostrar grelha</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="806"/>
        <source>Show/Hide grid</source>
        <translation>Mostrar/Esconder grelha</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="821"/>
        <source>Add picture</source>
        <translation>Adicionar imagem</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="830"/>
        <location filename="../mainwindow.ui" line="833"/>
        <source>Frame style</source>
        <translatorcomment>caixilho or Frame</translatorcomment>
        <translation>Estilo de caixilho</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="842"/>
        <location filename="../mainwindow.ui" line="845"/>
        <source>New Report Page</source>
        <translation>Nova Página de Report</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="854"/>
        <location filename="../mainwindow.ui" line="857"/>
        <source>Delete Report Page</source>
        <translation>Apagar Página de Report</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="866"/>
        <location filename="../mainwindow.ui" line="869"/>
        <source>Align Field Left</source>
        <translation>Alinhar Campo à Esquerda</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="878"/>
        <location filename="../mainwindow.ui" line="881"/>
        <source>Align Field Middle</source>
        <translation>Alinhar Campo ao Meio</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="890"/>
        <location filename="../mainwindow.ui" line="893"/>
        <source>Align Field Right</source>
        <translation>Alinhar Campo à Direita</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="902"/>
        <location filename="../mainwindow.ui" line="905"/>
        <source>Align Field Top</source>
        <translation>Alinhar Campo ao Topo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="914"/>
        <location filename="../mainwindow.ui" line="917"/>
        <source>Align Field Center</source>
        <translation>Alinhar Campo ao Centro</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="926"/>
        <location filename="../mainwindow.ui" line="929"/>
        <source>Align Field Bottom</source>
        <translation>Alinhar Campo ao Fundo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="938"/>
        <location filename="../mainwindow.ui" line="941"/>
        <source>Field Same Width</source>
        <translation>Campo Mesma Largura</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="950"/>
        <location filename="../mainwindow.ui" line="953"/>
        <source>Field Same Height</source>
        <translation>Campo Mesma Altura</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="962"/>
        <location filename="../mainwindow.ui" line="965"/>
        <source>Settings</source>
        <translation>Definições</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="977"/>
        <location filename="../mainwindow.ui" line="980"/>
        <source>Magnifying glass</source>
        <translation>Lupa</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="992"/>
        <location filename="../mainwindow.ui" line="995"/>
        <location filename="../mainwindow.cpp" line="2209"/>
        <source>Strikeout</source>
        <translation>Rasurado</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1004"/>
        <location filename="../mainwindow.ui" line="1007"/>
        <source>Group property</source>
        <translation>Propriedades do Grupo</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1012"/>
        <location filename="../mainwindow.ui" line="1015"/>
        <source>Check updates</source>
        <translation>Verificar Updates</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1027"/>
        <location filename="../mainwindow.ui" line="1030"/>
        <source>Add Diagram</source>
        <translation>Adicionar Diagrama</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1045"/>
        <location filename="../mainwindow.ui" line="1048"/>
        <source>Add Drawing</source>
        <translation>Adicionar Desenho</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1060"/>
        <location filename="../mainwindow.ui" line="1063"/>
        <source>Preview</source>
        <translation>Pré-visualizar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1075"/>
        <location filename="../mainwindow.ui" line="1078"/>
        <source>Data Source</source>
        <translation>Fonte de Dados</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1090"/>
        <location filename="../mainwindow.ui" line="1093"/>
        <source>Undo</source>
        <translation type="unfinished">Desfazar</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1096"/>
        <source>Ctrl+Z</source>
        <translation type="unfinished">Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1108"/>
        <location filename="../mainwindow.ui" line="1111"/>
        <source>Redo</source>
        <translation type="unfinished">Refazer</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1114"/>
        <source>Ctrl+Y</source>
        <translation type="unfinished">Ctrl+Y</translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1126"/>
        <location filename="../mainwindow.ui" line="1129"/>
        <source>Add Barcode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1134"/>
        <location filename="../mainwindow.ui" line="1137"/>
        <source>Readme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.ui" line="1149"/>
        <location filename="../mainwindow.ui" line="1152"/>
        <source>Add Rich Text</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="218"/>
        <source>Font name</source>
        <translation>Nome da Font</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="221"/>
        <source>Font size</source>
        <translation>Tamanho da Font</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="246"/>
        <source>Zoom</source>
        <translation>Zoom</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="260"/>
        <source>Frame width</source>
        <translation>Espessura do caixilho</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="396"/>
        <source>Report Title</source>
        <translation>Título do Report</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="402"/>
        <source>Report Summary</source>
        <translation>Resumo do Report</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="408"/>
        <source>Page Header</source>
        <translation>Cabeçalho da Página</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="414"/>
        <source>Page Footer</source>
        <translation>Rodapé</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="420"/>
        <source>Master Data</source>
        <translatorcomment>i think this should stay as MasterData</translatorcomment>
        <translation>Master Dados</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="426"/>
        <source>Data Grouping Header</source>
        <translation>Cabeçalho do agrupamentos de Dados</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="433"/>
        <source>Data Grouping Footer</source>
        <translation>Rodapé do Agrupamento de Dados</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="440"/>
        <location filename="../mainwindow.cpp" line="2388"/>
        <source>Master Header</source>
        <translation>Master Cabeçalho</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="446"/>
        <location filename="../mainwindow.cpp" line="2384"/>
        <source>Master Footer</source>
        <translation>Master Rodapé</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="478"/>
        <source>Line</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="484"/>
        <source>Line with arrow at the end</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="490"/>
        <source>Line with arrow at the start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="496"/>
        <source>Line with arrows at both side</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="502"/>
        <source>Rectangle</source>
        <translation>Rectângulo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="508"/>
        <source>Rounded rectangle</source>
        <translation>Rectângulo Arredondado</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="514"/>
        <source>Ellipse</source>
        <translation>Elipse</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="520"/>
        <source>Triangle</source>
        <translation>Triangulo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="526"/>
        <source>Rhombus</source>
        <translation>Losango</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="620"/>
        <source>&amp;%1 %2</source>
        <translation>&amp;%1 %2</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="773"/>
        <location filename="../mainwindow.cpp" line="1020"/>
        <source>Page %1</source>
        <translation>Página %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="952"/>
        <location filename="../mainwindow.cpp" line="964"/>
        <location filename="../mainwindow.cpp" line="1715"/>
        <location filename="../mainwindow.cpp" line="2507"/>
        <source>Saving</source>
        <translation>Guardando</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="952"/>
        <location filename="../mainwindow.cpp" line="964"/>
        <location filename="../mainwindow.cpp" line="1715"/>
        <location filename="../mainwindow.cpp" line="2507"/>
        <source>The report was changed.
Save the report?</source>
        <translation>O Report foi alterado
Deseja guardar o Report?</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="980"/>
        <source>Select File</source>
        <translation>Selecionar Ficheiro</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1422"/>
        <source>Save File</source>
        <translation>Guardar Ficheiro</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1422"/>
        <source>XML Files (*.xml)</source>
        <translation>Ficheiros XML (*.xml)</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1436"/>
        <location filename="../mainwindow.cpp" line="2650"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1643"/>
        <source>Font</source>
        <translation>Tipo de Letra</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1651"/>
        <source>Frame</source>
        <translation>Caixilho</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1999"/>
        <source>Aligment hor</source>
        <translation>Alinhamento hor</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2003"/>
        <location filename="../mainwindow.cpp" line="2064"/>
        <location filename="../mainwindow.cpp" line="2093"/>
        <source>Left</source>
        <translation>Esquerda</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2008"/>
        <location filename="../mainwindow.cpp" line="2036"/>
        <source>Center</source>
        <translation>Centro</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2013"/>
        <location filename="../mainwindow.cpp" line="2103"/>
        <source>Right</source>
        <translation>Direita</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2027"/>
        <source>Aligment ver</source>
        <translation>Alinhamento ver</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2031"/>
        <location filename="../mainwindow.cpp" line="2077"/>
        <location filename="../mainwindow.cpp" line="2113"/>
        <source>Top</source>
        <translation>topo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2041"/>
        <location filename="../mainwindow.cpp" line="2123"/>
        <source>Bottom</source>
        <translation>Fundo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2050"/>
        <source>Height</source>
        <translation>Altura</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2057"/>
        <source>Width</source>
        <translation>Largura</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2071"/>
        <source>Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2147"/>
        <source>FrameWidth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2167"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2216"/>
        <source>Printing</source>
        <translation>Imprimindo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2222"/>
        <source>Start New Numeration</source>
        <translation>Começar nova numeração</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2228"/>
        <source>Show In Group</source>
        <translation>Mostrar em Grupo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2234"/>
        <source>Start New Page</source>
        <translation>Iniciar Nova Pagina</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2240"/>
        <source>AutoHeight</source>
        <translation>Altura Automática</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2246"/>
        <source>IgnoreRatioAspect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2252"/>
        <source>ArrowStart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2258"/>
        <source>ArrowEnd</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2264"/>
        <source>BackgroundColor</source>
        <translation>Cor de Fundo</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2270"/>
        <source>BorderColor</source>
        <translation>Cor de Contorno</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2279"/>
        <source>FontColor</source>
        <translation>Cor de Letra</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2285"/>
        <source>BarcodeType</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2291"/>
        <source>BarcodeFrameType</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2364"/>
        <source>Report title</source>
        <translation>Título do report</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2368"/>
        <source>Report summary</source>
        <translation>Sumário do Report</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2372"/>
        <source>Page header</source>
        <translation>Cabeçalho de Página</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2376"/>
        <source>Page footer</source>
        <translation>Rodapé de Página</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2380"/>
        <source>Master data</source>
        <translation>Master Dados</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2392"/>
        <source>Data Group Header</source>
        <translation>Cabeçalho Grupo de Dados</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2396"/>
        <source>Data Group Footer</source>
        <translation>Rodapé Grupo de Dados</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="2650"/>
        <source>This object %1 can&apos;t be a parent for %2</source>
        <translation>Este objecto %1 nao pode ser pai para %2</translation>
    </message>
</context>
<context>
    <name>PageSettingDlg</name>
    <message>
        <location filename="../PageSettingDlg.ui" line="32"/>
        <source>Page settings</source>
        <translation>Definições de Pagina</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="42"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="51"/>
        <source>A4</source>
        <translation>A4</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="56"/>
        <source>Letter</source>
        <translation>Carta</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="64"/>
        <source>Width</source>
        <translation>Largura</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="74"/>
        <location filename="../PageSettingDlg.ui" line="91"/>
        <location filename="../PageSettingDlg.ui" line="174"/>
        <location filename="../PageSettingDlg.ui" line="191"/>
        <location filename="../PageSettingDlg.ui" line="208"/>
        <location filename="../PageSettingDlg.ui" line="225"/>
        <source>cm</source>
        <translation>cm</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="81"/>
        <source>Height</source>
        <translation>Altura</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="116"/>
        <source>Orientation</source>
        <translation>Orientação</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="124"/>
        <source>Portrait</source>
        <translation>Retracto</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="134"/>
        <source>Landscape</source>
        <translation>Paisagem</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="156"/>
        <source>Margins</source>
        <translation>Margens</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="164"/>
        <source>Left</source>
        <translation>Esquerda</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="181"/>
        <source>Right</source>
        <translation>Direita</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="198"/>
        <source>Top</source>
        <translation>Topo</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="215"/>
        <source>Bottom</source>
        <translation>Fundo</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="265"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.ui" line="272"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.cpp" line="29"/>
        <source>Cm</source>
        <translation>Cm</translation>
    </message>
    <message>
        <location filename="../PageSettingDlg.cpp" line="32"/>
        <source>Inch</source>
        <translation>Polegada</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../main.cpp" line="14"/>
        <source>QtRptDesigner</source>
        <translation>QtRPT Designer</translation>
    </message>
</context>
<context>
    <name>QTextEditEx</name>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="43"/>
        <source>Cut</source>
        <translation type="unfinished">Cortar</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="46"/>
        <location filename="../../CommonFiles/qtexteditex.ui" line="63"/>
        <location filename="../../CommonFiles/qtexteditex.ui" line="80"/>
        <location filename="../../CommonFiles/qtexteditex.ui" line="113"/>
        <location filename="../../CommonFiles/qtexteditex.ui" line="133"/>
        <location filename="../../CommonFiles/qtexteditex.ui" line="153"/>
        <location filename="../../CommonFiles/qtexteditex.ui" line="189"/>
        <location filename="../../CommonFiles/qtexteditex.ui" line="209"/>
        <location filename="../../CommonFiles/qtexteditex.ui" line="229"/>
        <location filename="../../CommonFiles/qtexteditex.ui" line="249"/>
        <location filename="../../CommonFiles/qtexteditex.ui" line="308"/>
        <source>...</source>
        <translation type="unfinished">...</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="60"/>
        <source>Copy</source>
        <translation type="unfinished">Copiar</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="77"/>
        <source>Paste</source>
        <translation type="unfinished">Colar</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="110"/>
        <source>Bold</source>
        <translation type="unfinished">Negrito</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="130"/>
        <source>Italic</source>
        <translation type="unfinished">Itálico</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="150"/>
        <source>Underline</source>
        <translation type="unfinished">Sublinhado</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="186"/>
        <source>Align left</source>
        <translation type="unfinished">Alinhar à esquerda</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="206"/>
        <source>Align center</source>
        <translation type="unfinished">Alinhar ao centro</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="226"/>
        <source>Align right</source>
        <translation type="unfinished">Alinhar à direita</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="246"/>
        <source>Align jusify</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="282"/>
        <source>List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="305"/>
        <source>Font color</source>
        <translation type="unfinished">Cor do Tipo de Letra</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="322"/>
        <source>Font</source>
        <translation type="unfinished">Tipo de Letra</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.ui" line="332"/>
        <source>Font size</source>
        <translation type="unfinished">Tamanho da Font</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.cpp" line="47"/>
        <source>Standard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.cpp" line="48"/>
        <source>Bullet List (Disc)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.cpp" line="49"/>
        <source>Bullet List (Circle)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.cpp" line="50"/>
        <source>Bullet List (Square)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.cpp" line="51"/>
        <source>Ordered List (Decimal)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.cpp" line="52"/>
        <source>Ordered List (Alpha lower)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../CommonFiles/qtexteditex.cpp" line="53"/>
        <source>Ordered List (Alpha upper)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ReportBand</name>
    <message>
        <location filename="../ReportBand.cpp" line="49"/>
        <source>Report title</source>
        <translation>Título do Report</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="55"/>
        <source>Report summary</source>
        <translation>Sumário do Report</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="61"/>
        <source>Page header</source>
        <translation>Cabeçalho da Página</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="67"/>
        <source>Page footer</source>
        <translation>Rodapé de Página</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="73"/>
        <source>Master band</source>
        <translation>Master Dados</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="80"/>
        <source>Master footer</source>
        <translation>Master Rodapé</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="86"/>
        <source>Master header</source>
        <translation>Master Cabeçalho</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="92"/>
        <source>Data Group Header</source>
        <translation>Cabeçalho Grupo de Dados</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="98"/>
        <source>Data Group Footer</source>
        <translation>Rodapé Grupo de Dados</translation>
    </message>
    <message>
        <location filename="../ReportBand.cpp" line="118"/>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
</context>
<context>
    <name>SettingDlg</name>
    <message>
        <location filename="../SettingDlg.ui" line="14"/>
        <source>Settings</source>
        <translation>Definições</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="24"/>
        <source>Grid</source>
        <translation>Grelha</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="32"/>
        <source>Measurement&apos;s unit</source>
        <translation>Unidade de Medida</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="42"/>
        <source>Cm</source>
        <translation>Cm</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="55"/>
        <source>Inch</source>
        <translation>Polegada</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="66"/>
        <source>Grid&apos;s step</source>
        <translation>step da Grelha</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="85"/>
        <source>Show grid</source>
        <translation>Mostrar grelha</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="95"/>
        <source>Internationalization</source>
        <translation>Internacionalização</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="103"/>
        <source>Language:</source>
        <translation>Lingua:</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="111"/>
        <source>System Default</source>
        <translation>Predefinição de Sistema</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="116"/>
        <source>Arabic عربي</source>
        <translation>Árabe عربي</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="121"/>
        <source>American English</source>
        <translation>Inglês Americano</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="126"/>
        <source>Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="131"/>
        <source>Georgian ქართული</source>
        <translation>Georgiano ქართული</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="136"/>
        <source>Portuguese</source>
        <translation>Português</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="141"/>
        <source>Russian Русский</source>
        <translation>Russo</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="146"/>
        <source>Serbian</source>
        <translation>Sérvio</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="151"/>
        <source>Serbian Latin</source>
        <translation>Sérvio Latim</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="156"/>
        <source>Ukraine Український</source>
        <translation>Ucraniano Український</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="169"/>
        <source>Check updates during start application</source>
        <translation>Verificar actualizações ao arrancar</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="191"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../SettingDlg.ui" line="198"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../SettingDlg.cpp" line="111"/>
        <source>Message QtRptDesigner</source>
        <translation>Mensagem QtRptDesigner</translation>
    </message>
    <message>
        <location filename="../SettingDlg.cpp" line="111"/>
        <source>The language for this application has been changed.
The change will take effect the next time the application is started.
Restart application?</source>
        <translation>A lingua para esta aplicação foi alterada
As alterações teram efeito da proxima vez que a aplicação iniciar
Reiniciar Aplicação?</translation>
    </message>
</context>
<context>
    <name>SqlDesigner</name>
    <message>
        <location filename="../SqlDesigner.ui" line="34"/>
        <source>Custom DS</source>
        <translation>DS Costumizado</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="44"/>
        <source>SQL DS</source>
        <translation>SQL DS</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="81"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="98"/>
        <source>Connection&apos;s parameters</source>
        <translation>Parametros de conexão</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="104"/>
        <source>Host name</source>
        <translation>Nome do Anfitrião</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="114"/>
        <location filename="../SqlDesigner.ui" line="225"/>
        <source>UTF8</source>
        <translation>UTF8</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="121"/>
        <source>Driver</source>
        <translation>Driver</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="128"/>
        <source>Check</source>
        <translation>Verificar</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="135"/>
        <source>Connection coding</source>
        <translation>codificação da Conexão</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="148"/>
        <source>Connection</source>
        <translation>Conexão</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="156"/>
        <source>QSQLITE</source>
        <translation>QSQLITE</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="161"/>
        <source>QMYSQL</source>
        <translation>QMYSQL</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="166"/>
        <source>QMYSQL3</source>
        <translation>QMYSQL3</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="171"/>
        <source>QODBC</source>
        <translation>QODBC</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="176"/>
        <source>QODBC3</source>
        <translation>QODBC3</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="181"/>
        <source>QPSQL</source>
        <translation>QPSQL</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="186"/>
        <source>QPSQL7</source>
        <translation>QPSQL7</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="194"/>
        <source>Charset coding</source>
        <translation>Codificção de Caracteres</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="201"/>
        <source>Password</source>
        <translation>Senha</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="211"/>
        <source>User name</source>
        <translation>Nome do Utilizador</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="218"/>
        <source>DB name</source>
        <translation>Nome da BD</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="297"/>
        <source>SQL query</source>
        <translation>SQL query</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="322"/>
        <location filename="../SqlDesigner.ui" line="325"/>
        <source>Clear diagram</source>
        <translation>Limpar Diagrama</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="340"/>
        <location filename="../SqlDesigner.ui" line="343"/>
        <source>Select</source>
        <translation>Selecionar</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="352"/>
        <location filename="../SqlDesigner.ui" line="355"/>
        <source>Redo</source>
        <translation>Refazer</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="358"/>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="367"/>
        <location filename="../SqlDesigner.ui" line="370"/>
        <source>Undo</source>
        <translation>Desfazar</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="373"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="385"/>
        <location filename="../SqlDesigner.ui" line="388"/>
        <source>Add relationship</source>
        <translation>Adicionar Relacionamento</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="397"/>
        <location filename="../SqlDesigner.ui" line="400"/>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.ui" line="403"/>
        <source>Del</source>
        <translation>Del</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.cpp" line="83"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.cpp" line="86"/>
        <source>Info</source>
        <translation>Info</translation>
    </message>
    <message>
        <location filename="../SqlDesigner.cpp" line="86"/>
        <source>Connected</source>
        <translation>Conectado</translation>
    </message>
</context>
<context>
    <name>TContainerField</name>
    <message>
        <location filename="../TContainerField.cpp" line="43"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="47"/>
        <source>Delete</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="54"/>
        <source>Move forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="60"/>
        <source>Move back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="235"/>
        <source>New image</source>
        <translation>Nova Imagem</translation>
    </message>
    <message>
        <location filename="../TContainerField.cpp" line="242"/>
        <source>New diagram</source>
        <translation>Novo Diagrama</translation>
    </message>
</context>
<context>
    <name>TContainerLine</name>
    <message>
        <location filename="../TContainerLine.cpp" line="228"/>
        <source>Delete</source>
        <translation type="unfinished">Apagar</translation>
    </message>
</context>
<context>
    <name>UpdateDlg</name>
    <message>
        <location filename="../../CommonFiles/updatedlg.ui" line="14"/>
        <location filename="../../CommonFiles/updatedlg.ui" line="38"/>
        <source>Updating</source>
        <translation>Actualizando</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/updatedlg.ui" line="33"/>
        <source>Progress</source>
        <translation>Progresso</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/updatedlg.ui" line="82"/>
        <source>Update</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/updatedlg.ui" line="89"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/updatedlg.cpp" line="30"/>
        <source>Open Directory</source>
        <translation>Abrir Directorio</translation>
    </message>
    <message>
        <location filename="../../CommonFiles/updatedlg.cpp" line="53"/>
        <source>Downloading %0. ..</source>
        <translation>a Descarregar %0..</translation>
    </message>
</context>
</TS>
