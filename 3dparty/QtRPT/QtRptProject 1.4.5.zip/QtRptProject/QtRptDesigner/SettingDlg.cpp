/*
Name: QtRptDesigner
Version: 1.4.5
Programmer: Aleksey Osipov
e-mail: aliks-os@ukr.net
2012-2014
*/

#include "SettingDlg.h"
#include "ui_SettingDlg.h"
#include <QMessageBox>
#include <QProcess>

SettingDlg::SettingDlg(QWidget *parent) : QDialog(parent),  ui(new Ui::SettingDlg) {
    ui->setupUi(this);
    QSettings settings(QCoreApplication::applicationDirPath()+"/setting.ini",QSettings::IniFormat);
    settings.setIniCodec("UTF-8");
    ui->dsp1->setValue(settings.value("GridStep",1).toDouble());
    ui->chShowGrid->setChecked(settings.value("ShowGrid",true).toBool());
    ui->chkUpdates->setChecked(settings.value("CheckUpdates",true).toBool());

    settings.beginGroup("language");

    QString language = settings.value("language").toString();
    if (language == "") //default system language
        ui->cmbLanguage->setCurrentIndex(0);

    else if (language == "Arabic")//english united states
        ui->cmbLanguage->setCurrentIndex(1);

    else if (language == "en_US")//english united states
        ui->cmbLanguage->setCurrentIndex(2);

    else if (language == "zh_CN")//Chinese
        ui->cmbLanguage->setCurrentIndex(3);

    else if (language == "ka_GE")//georgian
        ui->cmbLanguage->setCurrentIndex(4);

    else if (language == "pt_PT")//portuguese
        ui->cmbLanguage->setCurrentIndex(5);

    else if (language == "ru_RU")//russian
        ui->cmbLanguage->setCurrentIndex(6);

    else if (language == "sr_RS")//serbian cyrilic
        ui->cmbLanguage->setCurrentIndex(7);

    else if (language == "sr_RS@latin")
        ui->cmbLanguage->setCurrentIndex(8);

    else if (language == "uk_UA")
        ui->cmbLanguage->setCurrentIndex(9);

    langIndex = ui->cmbLanguage->currentIndex();

    QString measurement = settings.value("measurement").toString();
    if (measurement == "")
        ui->rbCm->setChecked(true);
    else if (measurement == "Cm")
        ui->rbCm->setChecked(true);
    else if (measurement == "Inch")
        ui->rbInch->setChecked(true);
    settings.endGroup();
}

void SettingDlg::showThis() {
    if (exec() == QDialog::Accepted) {
        QSettings settings(QCoreApplication::applicationDirPath()+"/setting.ini",QSettings::IniFormat);
        settings.setIniCodec("UTF-8");
        settings.setValue("GridStep", ui->dsp1->value());
        settings.setValue("ShowGrid", ui->chShowGrid->checkState());
        settings.setValue("CheckUpdates", ui->chkUpdates->checkState());

        settings.beginGroup("language");
        if (ui->cmbLanguage->currentIndex() != langIndex) {

            switch(ui->cmbLanguage->currentIndex())  {
            case 0://system default
                settings.setValue("language", "");
                break;
            case 1://Arabic
                settings.setValue("language", "ar");
                break;
            case 2://american english
                settings.setValue("language", "en_US");
                break;
            case 3://Chinese
                settings.setValue("language", "zh_CN");
                break;
            case 4://goergian
                settings.setValue("language", "ka_GE");
                break;
            case 5://portuguese
                settings.setValue("language", "pt_PT");
                break;
            case 6://russian
                settings.setValue("language", "ru_RU");
                break;
            case 7://serbian
                settings.setValue("language", "sr_RS");
                break;
            case 8://serbian latin
                settings.setValue("language", "sr_RS@latin");
                break;
            case 9://ukraine
                settings.setValue("language", "uk_UA");
                break;
            }
            QMessageBox::StandardButton reply;
            reply = QMessageBox::question(this, tr("Message QtRptDesigner"),tr("The language for this application has been changed.\n"
                                                                               "The change will take effect the next time the application is started.\nRestart application?"),
                                             QMessageBox::Yes | QMessageBox::No);
            if (reply == QMessageBox::Yes) {
                this->parentWidget()->close();
                QProcess::startDetached(QApplication::applicationFilePath());
            }
        }

        if (ui->rbCm->isChecked())
            settings.setValue("measurement", "Cm");
        else if (ui->rbInch->isChecked())
            settings.setValue("measurement", "Inch");
        else
            settings.setValue("measurement", "Cm");

        settings.endGroup();
    }
}

SettingDlg::~SettingDlg() {
    delete ui;
}
