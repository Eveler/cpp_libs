#include <QtPlugin>

Q_IMPORT_PLUGIN(ReportEditor)
Q_IMPORT_PLUGIN(PageEditor)
Q_IMPORT_PLUGIN(DatasetEditor)
Q_IMPORT_PLUGIN(ScriptEditor)
Q_IMPORT_PLUGIN(Preview)

