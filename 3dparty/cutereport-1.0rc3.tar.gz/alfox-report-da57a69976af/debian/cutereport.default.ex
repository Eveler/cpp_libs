# Defaults for cutereport initscript
# sourced by /etc/init.d/cutereport
# installed at /etc/default/cutereport by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
