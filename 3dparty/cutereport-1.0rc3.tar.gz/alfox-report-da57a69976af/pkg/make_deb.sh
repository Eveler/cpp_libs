#!/bin/sh

export QT_SELECT=qt5_work

cd ..
debuild -i -us -uc -b -r